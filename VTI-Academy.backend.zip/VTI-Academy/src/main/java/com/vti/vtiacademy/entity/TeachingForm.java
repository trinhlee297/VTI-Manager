package com.vti.vtiacademy.entity;

public enum TeachingForm {
    ONLINE, OFFLINE, ALL
}
