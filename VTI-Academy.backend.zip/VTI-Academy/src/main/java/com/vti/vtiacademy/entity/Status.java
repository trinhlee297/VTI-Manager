package com.vti.vtiacademy.entity;

public enum Status {
    ACTIVE, INACTIVE, PENDING, BLOCK
}
