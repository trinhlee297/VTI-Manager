package com.vti.vtiacademy.form;

import com.vti.vtiacademy.dto.SearchBase;
import com.vti.vtiacademy.entity.Role;
import lombok.Data;

import java.time.LocalDate;
@Data
public class AccountFilterForm extends SearchBase {
    private String username;
//    private LocalDate dateOfBirth;
//    private String address;
//    private String password;
//    private String fullName;
//    private Role role;
//    private String phoneNumber;
//    private String email;
//    private String facebook;
//    private String information;
}
