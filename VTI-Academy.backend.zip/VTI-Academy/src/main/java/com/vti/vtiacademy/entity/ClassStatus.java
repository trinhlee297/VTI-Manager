package com.vti.vtiacademy.entity;

public enum ClassStatus {
    IN_PROGRESS, PENDING, CLOSE
}
