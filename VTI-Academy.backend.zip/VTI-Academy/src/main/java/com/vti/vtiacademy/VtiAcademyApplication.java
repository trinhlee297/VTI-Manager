package com.vti.vtiacademy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VtiAcademyApplication {

    public static void main(String[] args) {
        SpringApplication.run(VtiAcademyApplication.class, args);
    }

}
